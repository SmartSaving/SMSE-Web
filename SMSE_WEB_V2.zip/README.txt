SMSE WEB V2
- Tampilan dirapikan agar lebih dekat dengan referensi HMI.
- Supabase live refresh 2 detik.
- Alarm Web: sisa kosong <= 10 cm.
- Node/Supabase tetap menjadi sumber data.
- Jalankan index.html.
